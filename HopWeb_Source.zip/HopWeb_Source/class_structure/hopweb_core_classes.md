# HopWeb Core App Classes (com.venter.*)

## classes.dex

### com.venter.club.client.BuildConfig

### com.venter.club.client.ClientUtils
- **methods:** `$r8$lambda$5Mc6n9D8ijtRWq9cJFBU0Oy4DHs`, `$r8$lambda$GBWdqBwIUE1gmgjyIRrJqQ03rPg`, `$r8$lambda$X59w6MKcXVVnpx_RM244Sr0O7VM`, `$r8$lambda$YlkLgc9gxYyuLL3uE0ObsWglsNk`, `$r8$lambda$ZYUaQsa-2oZRwXuVZ_foQ48tRH4`, `$r8$lambda$haxIKWzWdUXkZ2PjrpI3Faq1KRE`, `$r8$lambda$kjo-8_ldwXRplGeNiBvMPnkFgto`, `$r8$lambda$lVke9PBsL4s-u6KHGTpiEYZg7cA`, `access$getWebView$p`, `generateVerifiedCodeAndSendEmail`, `generateVerifiedCodeAndSendEmail$lambda$1`, `generateVerifiedCodeAndSendEmail$lambda$1$lambda$0`, `getLocalUserConf`, `getVersion`, `login`, `login$lambda$5`, `login$lambda$5$lambda$4`, `register`, `register$lambda$3`, `register$lambda$3$lambda$2`, `removeLocalUserConf`, `requestTimestamp`, `requireUserInf`, `requireUserInf$lambda$6`, `requireUserInfRPC`, `resetPwd`, `resetPwd$lambda$7`, `saveLoginConf`

### com.venter.club.client.ClientWebView
- **extends:** `android.webkit.WebView`
- **methods:** `addJavascriptInterface`, `getSettings`, `loadUrl`, `openClubCenter`, `openLogin`

### com.venter.club.client.R

### com.venter.club.client.Utils
- **methods:** `access$getVenterClubUrl$cp`

### com.venter.codeeditor.BuildConfig

### com.venter.codeeditor.CodeEditor
- **extends:** `textwarrior.TextEditor`
- **methods:** `moveCaret`, `moveCursor`, `setEvent`, `setText`

### com.venter.codeeditor.R

### com.venter.filepicker.BookmarksAdapter
- **extends:** `androidx.recyclerview.widget.RecyclerView$Adapter`
- **methods:** `$r8$lambda$s8ugtUCKuwkJNmkmk2Eb7599nkU`, `$r8$lambda$wRrLd5kGgcSSsvIZUJGatyFTRlg`, `getItemCount`, `onBindViewHolder`, `onBindViewHolder$lambda$0`, `onBindViewHolder$lambda$1`, `onCreateViewHolder`

### com.venter.filepicker.BuildConfig

### com.venter.filepicker.FileAdapter
- **extends:** `androidx.recyclerview.widget.RecyclerView$Adapter`
- **methods:** `$r8$lambda$0ckf4z5RlZqjE9F-C0p9a8rvWRs`, `$r8$lambda$Jw49b4cjMqyUSOJ28i9DYvTULhg`, `$r8$lambda$XgZ9W1zz57hObxJ35ulB5xCM-80`, `$r8$lambda$uq_kRwz7Em3n__0IggQNgQTvpig`, `getItemCount`, `onBindViewHolder`, `onBindViewHolder$lambda$1`, `onBindViewHolder$lambda$1$lambda$0`, `onBindViewHolder$lambda$2`, `onBindViewHolder$lambda$3`, `onCreateViewHolder`

### com.venter.filepicker.FileModel
- **methods:** `getName`, `getPath`, `getType`

### com.venter.filepicker.FilePicker
- **methods:** `$r8$lambda$0equ_d7LoSDYtN942QINX5-1wQk`, `$r8$lambda$1O-Js47ldpcsV2LD2DhoHxeHafs`, `$r8$lambda$7P5kZvggVTSmCi7fyzvmN91o4fE`, `$r8$lambda$RZ8d2SRDk9ypRWfNm7EUNmDySvc`, `$r8$lambda$cm8b8V-TNnycG8gMl1nmRVSl7CM`, `$r8$lambda$e8c5nR8Rd8defeNRRaK_6j0OBkc`, `$r8$lambda$fafqut6cU2fM8Q6pYSS_VuzmwWw`, `$r8$lambda$lJ1IYaawmeqGy-GJdN5jw-W05SU`, `$r8$lambda$rBX2zE3I6q_995fstKIS8X5DeJI`, `$r8$lambda$uvIgRlIwOqOtTg0vJni00zSZ33E`, `access$getBookmarkManager$p`, `access$getCurrectFolder$p`, `access$getSearchEditText$p`, `access$goto`, `dp2px`, `getContext`, `getDialog`, `getDialogTitle`, `getForPickingFolder`, `getHomeFolder`, `getOnSelectedListener`, `goto`, `goto$default`, `goto$lambda$10`, `isNightTheme`, `searchMode`, `searchMode$default`, `setDialog`, `setDialogTitle`, `setForPickingFolder`, `setHomeFolder`, `setOnSelectedListener`, `show`, `show$lambda$2`, `show$lambda$2$lambda$1`, `show$lambda$3`, `show$lambda$4`, `show$lambda$5`, `show$lambda$6`, `show$lambda$8`, `show$lambda$9`, `showBookmarks`, `showBookmarks$lambda$12`

### com.venter.filepicker.FileType
- **extends:** `java.lang.Enum`
- **methods:** `$values`, `ordinal`, `valueOf`, `values`

### com.venter.filepicker.OnItemClickListener
- **methods:** `onClick`

### com.venter.filepicker.OnItemLongClickListener
- **methods:** `onLongClick`

### com.venter.filepicker.OnSelectedListener
- **methods:** `run`

### com.venter.filepicker.R

## classes2.dex

### com.venter.hopweb.ABIWarningActivity
- **extends:** `com.venter.hopweb.BaseActivity`
- **methods:** `$r8$lambda$SQQw7cNahlzcMVmEF_Wq0IceCzg`, `finish`, `getBinding`, `getLayoutInflater`, `onCreate`, `onCreate$lambda$0`, `setBinding`, `setContentView`

### com.venter.hopweb.AboutActivity
- **extends:** `com.venter.hopweb.BaseActivity`
- **methods:** `$r8$lambda$59k4gGG4kSePqFcBALp2hXZsvZQ`, `$r8$lambda$UZ4z5VkrQAHj0iQQvKoaNTYUDpI`, `getAssets`, `getLayoutInflater`, `getString`, `lambda$onCreate$0`, `lambda$onCreate$1`, `onCreate`, `setContentView`

### com.venter.hopweb.AppConvertActivity
- **extends:** `com.venter.hopweb.BaseActivity`
- **methods:** `$r8$lambda$5NQ0QjIbOT4z3NfmGwwMCGRR1cE`, `$r8$lambda$LHwoV0zIdTBfxU5LDdTwiVvocpE`, `$r8$lambda$_K_2xabbhc4IVEqZu6FvFWNGy3E`, `$r8$lambda$g4pi34iY8SLePFKnVu3szQYx294`, `$r8$lambda$q2T22KSs0mw4uDhpHApACuixUzI`, `$r8$lambda$uh1PbDzO3VHQifb-b2uIYIncQo4`, `getAppIconPath`, `getAppName`, `getAppPackageName`, `getBinding`, `getConfigFile`, `getHomePage`, `getIntent`, `getLayoutInflater`, `getPhpServerPort`, `getProjectFolder`, `getScreenRotation`, `getSplashPath`, `getString`, `getTitleBarBackgroundColor`, `getVersionCode`, `getVersionName`, `getWithPHPEnv`, `isAllowCamera`, `isAllowLongClick`, `isAllowMicrophone`, `isAllowSwipeRefresh`, `isAllowZoom`, `isAutoplay`, `isFullscreen`, `isHideTitleBar`, `isPCMode`, `isShowLoadingUI`, `onCreate`, `onCreate$lambda$0`, `onCreate$lambda$2`, `onCreate$lambda$2$lambda$1`, `onCreate$lambda$5`, `onCreate$lambda$5$lambda$4`, `onCreate$lambda$5$runBuild`, `onCreate$lambda$5$runBuild$lambda$3`, `runOnUiThread`, `setAllowCamera`, `setAllowLongClick`, `setAllowMicrophone`, `setAllowSwipeRefresh`, `setAllowZoom`, `setAppIconPath`, `setAppName`, `setAppPackageName`, `setAutoplay`, `setBinding`, `setConfigFile`, `setContentView`, `setFullscreen`, `setHideTitleBar`, `setHomePage`, `setPCMode`, `setPhpServerPort`, `setProjectFolder`, `setScreenRotation`, `setShowLoadingUI`, `setSplashPath`, `setTitleBarBackgroundColor`, `setVersionCode`, `setVersionName`, `setWithPHPEnv`, `toast`

### com.venter.hopweb.BaseActivity
- **extends:** `androidx.appcompat.app.AppCompatActivity`
- **methods:** `$r8$lambda$lOyoZN5LcTVMmrxbDYat2s72-rM`, `attachBaseContext`, `finish`, `getApplicationContext`, `getResources`, `getString`, `getWindow`, `lambda$onKeyDown$0`, `onCreate`, `onCreateOptionsMenu`, `onDestroy`, `onKeyDown`, `onNewIntent`, `onOptionsItemSelected`, `onPause`, `onResume`, `onSaveInstanceState`, `onWindowFocusChanged`, `requestWindowFeature`, `runAndIfNotFrontRunWhenResume`, `runOnUiThread`, `setTheme`, `toast`

### com.venter.hopweb.BaseFragment
- **extends:** `androidx.fragment.app.Fragment`
- **methods:** `getTag`, `onViewCreated`

### com.venter.hopweb.BootActivity
- **extends:** `com.venter.hopweb.BaseActivity`
- **methods:** `finish`, `getFilesDir`, `getLayoutInflater`, `onCreate`, `runOnUiThread`, `setContentView`, `startActivity`

### com.venter.hopweb.BuildConfig

### com.venter.hopweb.ClubClientActivity
- **extends:** `com.venter.hopweb.BaseActivity`
- **methods:** `$r8$lambda$0U6zn5OhgfdmnbSZXrjr_3Jidts`, `finish`, `getBinding`, `getLayoutInflater`, `onCreate`, `onCreateOptionsMenu`, `onCreateOptionsMenu$lambda$0`, `onKeyDown`, `setBinding`, `setContentView`, `setSupportActionBar`

### com.venter.hopweb.CrashHandler
- **methods:** `err`, `getInstance`, `init`, `uncaughtException`

### com.venter.hopweb.EditorActivity
- **extends:** `com.venter.hopweb.BaseActivity`
- **methods:** `$r8$lambda$-T-7d3nBIeIeXxSMzk2RIUBGQak`, `$r8$lambda$03DaGGMw9idc5fxatYkiLoot5UE`, `$r8$lambda$13XJMEx20-_KHR4dOz9jRbbw8Lk`, `$r8$lambda$1i2q_lpdKzlu7WCs5lE1F3N-6WI`, `$r8$lambda$34WD6Xj5M6WIhX-QBh81xYtfm84`, `$r8$lambda$4TBTrD1_h01HBh-R3dXAP9Q2YGQ`, `$r8$lambda$57qd3zkutxc3DpbXseoiQQM-ZBA`, `$r8$lambda$5JQI9uT35m9gHt0S9j5KK3Onj3A`, `$r8$lambda$60Zpg3Y8pLzEDbdcZoMxDlXB6Ms`, `$r8$lambda$6bBEtQSTXKUbYGaZN52-eW7qf4M`, `$r8$lambda$7EPEWA2zO2NndMxnscriZxlnXFA`, `$r8$lambda$7YGOoHlC-X2wUSpiBNNkEJk3JKk`, `$r8$lambda$7w6UpJhmwoWP6h90q6UZwowMjY0`, `$r8$lambda$82JpIwJxecXa2Cad8nCsYJEpIG0`, `$r8$lambda$8ousuO2fjyq-u_XcE5ASzsiSEEI`, `$r8$lambda$91FJES-gZJhZgEY9D8KNtxMfQ7s`, `$r8$lambda$AvpnUgtR9feaphqgRy3CjZrZoO4`, `$r8$lambda$BvEHXeh3vCewwsXTWtkv7N875WU`, `$r8$lambda$C0Hf6scPHRQjXJS5OH9E41Ub0wg`, `$r8$lambda$DEotfqtHWrpUYonvQDDpiEji2ok`, `$r8$lambda$EPoGrz9xnDT6DbywGjcwnhCdNrM`, `$r8$lambda$EftehKulvcouL9vVhdphE0uJk-k`, `$r8$lambda$Fi7jkmfNpxp2Fd4qWxGWyD3Y4y0`, `$r8$lambda$H3Q80Nkw3OctwFVtDBv-cSQhUj4`, `$r8$lambda$KVNNCPbbYc3kNXzAOdBX0jac8O8`, `$r8$lambda$MKkaZMRLGGjSuUkomwex5pRoCV8`, `$r8$lambda$NtjavIQxuMBAcxw0XQDdBK37iH8`, `$r8$lambda$PENGfpfVlJXCoDG_wo4i03Iwcns`, `$r8$lambda$QCrdA9YJBNjHry-SM2OXpMe1zMI`, `$r8$lambda$QQkqTsve_WQHN9H28772ljFq-3U`, `$r8$lambda$RrPd26hImIJeLnFPz4xbdcmUfWE`, `$r8$lambda$S-sXKwlrRmASfWRxw2oYy8faySg`, `$r8$lambda$T1tqenSdPnD1CYV8ar5pU0UdVxI`, `$r8$lambda$ZhtCWySgevzY4FffE_kLQMGdUT0`, `$r8$lambda$aCPCAJPL5xzSGPSADdl22BtfZ_c`, `$r8$lambda$aOs5cGOSD6kCI-dHscK2ESbRmjs`, `$r8$lambda$ab-WvCUVjGBwcnYhinfbquokeos`, `$r8$lambda$bD8yT8u6DS-wlfGehK1fGubnFIw`, `$r8$lambda$bxwQkgc3rFL9aoXAKojfXZ6jpMs`, `$r8$lambda$dT2rgR5w_d_iG1AnXO8o2XdmSpY`, `$r8$lambda$dUKgavRxkWHx3Z5elSXYqvHiXRc`, `$r8$lambda$dl_LNU9s6cIgcHHvHByNTDq1WoI`, `$r8$lambda$dvhM57dxlP7Gw165h9RRWgZqjlU`, `$r8$lambda$j7OxnqZNjqzTE99vK6ZVkXV5_wQ`, `$r8$lambda$k_lGw2_psYU63GczUObssX1fm0U`, `$r8$lambda$klJws2iG3f7ODHOW6QAhL06JXjo`, `$r8$lambda$krbmztwYyBaNhgkQBG_u-Wh113E`, `$r8$lambda$lHruuE8Vjion8wFBE3AOuZmwh4k`, `$r8$lambda$qE1Q9nf8pWMUyiYqZC18RmAZ6zk`, `$r8$lambda$uRoAmXT-u_qmFdBerr7rH6UYZvM`, `$r8$lambda$v3dO5doRsOCuW-cPx06LtKunyxY`, `$r8$lambda$w2clxHmKlIteBU1DR3T_-lI0VWc`, `$r8$lambda$xlUH6eFsUsvNwgN2irLt0GI1it4`, `$r8$lambda$ypuv1IxNspfXfqVNOwW_-JFnLuE`, `-$$Nest$fgetexplorerView`, `-$$Nest$fgetprojectFile`, `createGitRemote`, `exitAndClean`, `explorerOnClick`, `finish`, `getApplicationContext`, `getFilesDir`, `getIntent`, `getLayoutInflater`, `getMainLooper`, `getMenuInflater`, `getString`, `lambda$createGitRemote$48`, `lambda$exitAndClean$53`, `lambda$exitAndClean$54`, `lambda$explorerOnClick$26`, `lambda$explorerOnClick$27`, `lambda$explorerOnClick$28`, `lambda$explorerOnClick$29`, `lambda$explorerOnClick$30`, `lambda$explorerOnClick$31`, `lambda$explorerOnClick$32`, `lambda$explorerOnClick$33`, `lambda$onCreate$0`, `lambda$onCreate$1`, `lambda$onCreate$10`, `lambda$onCreate$11`, `lambda$onCreate$12`, `lambda$onCreate$13`, `lambda$onCreate$14`, `lambda$onCreate$15`, `lambda$onCreate$16`, `lambda$onCreate$17`, `lambda$onCreate$18`, `lambda$onCreate$19`, `lambda$onCreate$2`, `lambda$onCreate$20`, `lambda$onCreate$21`, `lambda$onCreate$22`, `lambda$onCreate$23`, `lambda$onCreate$24`, `lambda$onCreate$25`, `lambda$onCreate$3`, `lambda$onCreate$4`, `lambda$onCreate$5`, `lambda$onCreate$6`, `lambda$onCreate$7`, `lambda$onCreate$8`, `lambda$onCreate$9`, `lambda$onKeyDown$55`, `lambda$onResume$56`, `lambda$receiveIntent$49`, `lambda$receiveIntent$50`, `lambda$receiveIntent$51`, `lambda$receiveIntent$52`, `lambda$showGitPullDialog$41`, `lambda$showGitPullDialog$42`, `lambda$showGitPullDialog$43`, `lambda$showGitPullDialog$44`, `lambda$showGitPullDialog$45`, `lambda$showGitPullDialog$46`, `lambda$showGitPullDialog$47`, `lambda$showGitPushDialog$34`, `lambda$showGitPushDialog$35`, `lambda$showGitPushDialog$36`, `lambda$showGitPushDialog$37`, `lambda$showGitPushDialog$38`, `lambda$showGitPushDialog$39`, `lambda$showGitPushDialog$40`, `onCreate`, `onCreateOptionsMenu`, `onDestroy`, `onKeyDown`, `onNewIntent`, `onResume`, `onSaveInstanceState`, `onWindowFocusChanged`, `receiveIntent`, `registerForActivityResult`, `runAndIfNotFrontRunWhenResume`, `runOnUiThread`, `setContentView`, `setSupportActionBar`, `showGitPullDialog`, `showGitPushDialog`, `startActivity`, `toast`

### com.venter.hopweb.EditorManager
- **methods:** `addFile`, `chooseEverywherePreview`, `close`, `closeFile`, `controlOptionsMenu`, `destroy`, `everywherePreview`, `getMode`, `init`, `lambda$addFile$25`, `lambda$chooseEverywherePreview$19`, `lambda$closeFile$21`, `lambda$closeFile$22`, `lambda$closeFile$23`, `lambda$closeFile$24`, `lambda$controlOptionsMenu$10`, `lambda$controlOptionsMenu$11`, `lambda$controlOptionsMenu$12`, `lambda$controlOptionsMenu$13`, `lambda$controlOptionsMenu$14`, `lambda$controlOptionsMenu$15`, `lambda$controlOptionsMenu$16`, `lambda$controlOptionsMenu$17`, `lambda$controlOptionsMenu$18`, `lambda$controlOptionsMenu$8`, `lambda$controlOptionsMenu$9`, `lambda$save$20`, `lambda$setFile$0`, `lambda$setFile$1`, `lambda$setFile$2`, `lambda$setFile$3`, `lambda$setFile$4`, `lambda$setFile$5`, `lambda$setFile$6`, `lambda$setFile$7`, `preview`, `previewForFile`, `previewHTML`, `previewPHP`, `reSetCharsAdder`, `save`, `setFile`, `setFileItemCardSelected`, `setOptionsMenuVisibility`, `setPreviewOnClick`, `setPreviewOnLongClick`, `star`, `unstar`

### com.venter.hopweb.ErrorActivity
- **extends:** `com.venter.hopweb.BaseActivity`
- **methods:** `$r8$lambda$aKR0FNLZPWPGIpGh03eZ0L5ZonA`, `finish`, `getIntent`, `getLayoutInflater`, `getPackageManager`, `getPackageName`, `getSystemService`, `lambda$onCreate$0`, `onCreate`, `setContentView`

### com.venter.hopweb.ExplorerManager
- **methods:** `-$$Nest$sfgetpathTvHsv`, `createNewFile`, `hideExplorer`, `importFile`, `init`, `lambda$createNewFile$0`, `lambda$createNewFile$1`, `lambda$importFile$2`, `lambda$importFile$3`, `lambda$importFile$4`, `reGetTitle`, `showExplorer`, `updatePath`

### com.venter.hopweb.GitHouse
- **methods:** `$r8$lambda$8rs2RCQR-9rcgtmmMLaGiumbHgg`, `$r8$lambda$_qgI9Jw5XJZItQhTip1V-KSAPuM`, `addAllAndCommit`, `addRemote`, `clone`, `getBranchFirst`, `getContext`, `getCreditConfig`, `getRemoteNameFirst`, `getRemoteSize`, `initRepo`, `openRepo`, `pull`, `push`, `readCredentialsProvider`, `saveCredentialsProvider`, `showAndroidLowVersionDialog`, `showLinkToGitHubDialog`, `showLinkToGitHubDialog$lambda$0`, `showLinkToGitHubDialog$lambda$1`

### com.venter.hopweb.IdeaSkyDetailActivity
- **extends:** `com.venter.hopweb.BaseActivity`
- **methods:** `$r8$lambda$37FJ41V-5OVaYJHxXUANyiab2Pw`, `$r8$lambda$41UK9ER0YS6JHp-wm6P1tNFhFvA`, `$r8$lambda$6-qYTMPeljPjWUbPx2-oFq2K-8o`, `$r8$lambda$A1EkhwV5JCSW6qBlH6kH-pp0tQI`, `$r8$lambda$CGCpIsX1vxAMhrixPuTENSPqlmI`, `$r8$lambda$CYj4dj8X4K8mRjT8PsBVxXkOTM8`, `$r8$lambda$GuQYFrZBQPkRkq1GBS1EI1n0aMo`, `$r8$lambda$_0oWnU3zhaez6_NJRGzh_Qe-H28`, `$r8$lambda$_rlrLH7KeHrsAtrZcWPh1hLvmU4`, `$r8$lambda$clLrn10KINvCMyXYaLxUksOqIa4`, `$r8$lambda$g8cMclwCe3Q182nsMLGBIt0gXE4`, `$r8$lambda$hqtadQTcHuK-wtgcux_Y13djqfA`, `$r8$lambda$o0ulr3I5xq6l1Fdgwa3_e8mV8B0`, `$r8$lambda$sw3EKijJDWPsxtDsEn8ZgXgH5YI`, `$r8$lambda$zjeaf4h-PSWVjvALkE5u3-9W7IE`, `downloadProject`, `downloadProject$lambda$15`, `downloadProject$lambda$15$lambda$13`, `downloadProject$lambda$15$lambda$13$lambda$12`, `downloadProject$lambda$15$lambda$14`, `getBinding`, `getFilesDir`, `getIntent`, `getLayoutInflater`, `getString`, `onCreate`, `onCreate$lambda$0`, `onCreate$lambda$1`, `onCreate$lambda$11`, `onCreate$lambda$11$lambda$10`, `onCreate$lambda$11$lambda$9`, `onCreate$lambda$11$lambda$9$lambda$2`, `onCreate$lambda$11$lambda$9$lambda$4`, `onCreate$lambda$11$lambda$9$lambda$6`, `onCreate$lambda$11$lambda$9$lambda$6$lambda$5`, `onCreate$lambda$11$lambda$9$lambda$8`, `onCreate$lambda$11$lambda$9$lambda$8$lambda$7`, `runAndIfNotFrontRunWhenResume`, `runOnUiThread`, `setBinding`, `setContentView`

### com.venter.hopweb.IdeaSkyItemsActivity
- **extends:** `com.venter.hopweb.BaseActivity`
- **methods:** `$r8$lambda$5r4w13PWd1ZZiE74Xyd_DNurJSU`, `$r8$lambda$8G74y8CV-BfYFj3pBO7fwQ2DWLc`, `$r8$lambda$Bw0qUogOFb3KHA98UXI_NEwetxo`, `$r8$lambda$F5Ir3GNZam45ULOkJjm1GmveEV0`, `$r8$lambda$KHssVZ11-ei8EDHW97d5l5lh2uU`, `$r8$lambda$L_z30oGbx5Saq0IX0DrZHpaFav8`, `$r8$lambda$YLiscyeoyUx2D_pF4IMdsSUaAVY`, `$r8$lambda$bEz67whBU1tF5_JDVjyEyJozf5c`, `$r8$lambda$bJ2zYn40fmYoXXw8oPXaF1e_qyI`, `$r8$lambda$ciYFu7S7pNXSXh4uM6bAfnn97bQ`, `$r8$lambda$p-SAzADZpJAjzh_Pizvlxqee19E`, `$r8$lambda$t0bn-orYErqZx1IdPiE4Ort8HaA`, `$r8$lambda$xDgsS_vUoZbVw4qIyd4DM6a1VJk`, `$r8$lambda$xbX0TuRJsNd77xD_zG5jxN0r_iQ`, `getBinding`, `getLayoutInflater`, `getOptionsMenu`, `getString`, `loadGlobalItems`, `loadGlobalItems$lambda$7`, `loadGlobalItems$lambda$7$lambda$5`, `loadGlobalItems$lambda$7$lambda$6`, `loadHotItems`, `loadHotItems$lambda$11`, `loadHotItems$lambda$11$lambda$10`, `loadHotItems$lambda$11$lambda$9`, `loadNewItems`, `loadNewItems$lambda$4`, `loadNewItems$lambda$4$lambda$2`, `loadNewItems$lambda$4$lambda$3`, `onCreate`, `onCreate$lambda$1`, `onCreate$lambda$1$lambda$0`, `onCreateOptionsMenu`, `onCreateOptionsMenu$lambda$13`, `onCreateOptionsMenu$lambda$13$lambda$12`, `onCreateOptionsMenu$lambda$14`, `runOnUiThread`, `setBinding`, `setContentView`, `setOptionsMenu`, `setSupportActionBar`, `setTitle`, `startActivity`

### com.venter.hopweb.IdeaSkyUploadActivity
- **extends:** `com.venter.hopweb.BaseActivity`
- **methods:** `$r8$lambda$-_rdZ-S_xdrIo78ZC6x8nR7GApA`, `$r8$lambda$0x3nXFzdqxChNFPJRHmbHoEHes0`, `$r8$lambda$1IgcCVhqNmC4PZPMh_s3fBLPfWg`, `$r8$lambda$2k0VTJ48QzcMgv-g1yixQ2YgzE0`, `$r8$lambda$9dMm698wmfX52GNF1YvHOiG0Vy4`, `$r8$lambda$AGq1WUZR7i-WxGjACy7djNEQQuI`, `$r8$lambda$OyvI-LkLsKeI1cBcj9FqaufSpP8`, `$r8$lambda$Pa67pMUYsf3N_alIOeEvsXBzVsc`, `$r8$lambda$SfzbpnU8DgjpMXT_QaT0nj7ohHM`, `$r8$lambda$UHFuIc5ywKCUW0ht-siH6ZpIa1E`, `$r8$lambda$UyUQLkh4JK8UwGbU-RRKbNq9lxE`, `$r8$lambda$WhGDPaZeu-vTSK55uGTiNchj560`, `$r8$lambda$iD9iqOil1VJP6Cuebm1UEsSnPL4`, `$r8$lambda$ipNegxo-h_ThquDgkj1Vr3O0jmM`, `$r8$lambda$pkYq0BTzz7nrwYyjU-8xV7MAeSk`, `$r8$lambda$sxQ_yQrjcOJ_uJyz0HQNNKCdB98`, `_get_screenshotCardViewOnClickListener_$lambda$21`, `_get_screenshotCardViewOnClickListener_$lambda$21$lambda$20`, `finish`, `getBinding`, `getContentResolver`, `getFilesDir`, `getIntent`, `getLayoutInflater`, `getScreenshotCardViewOnClickListener`, `getString`, `onCreate`, `onCreate$lambda$0`, `onCreate$lambda$14`, `onCreate$lambda$14$lambda$13`, `onCreate$lambda$14$lambda$13$lambda$10`, `onCreate$lambda$14$lambda$13$lambda$11`, `onCreate$lambda$14$lambda$13$lambda$12`, `onCreate$lambda$14$lambda$13$lambda$9`, `onCreate$lambda$3`, `onCreate$lambda$3$lambda$2`, `onCreate$lambda$4`, `onCreate$lambda$7`, `onCreate$lambda$7$lambda$6`, `onSaveInstanceState`, `onSaveInstanceState$lambda$16`, `pickImageLauncher$lambda$23`, `registerForActivityResult`, `runOnUiThread`, `setBinding`, `setContentView`, `startActivity`, `stepToInfInterface`, `stepToInfInterface$lambda$19`, `stepToInfInterface$lambda$19$lambda$18`, `toast`

### com.venter.hopweb.IdeaSkyUploadChooseActivity
- **extends:** `com.venter.hopweb.BaseActivity`
- **methods:** `$r8$lambda$ExSfZRJoWADH6ZDqbnH9Pfg1CZo`, `$r8$lambda$ajtlXizdYeugkFbmdN4DeBDxKbU`, `finish`, `getBinding`, `getIntent`, `getLayoutInflater`, `onCreate`, `onCreate$lambda$0`, `onCreate$lambda$1`, `setBinding`, `setContentView`, `skip`, `startActivity`

### com.venter.hopweb.IdeaSkyUploadFinishActivity
- **extends:** `com.venter.hopweb.BaseActivity`
- **methods:** `$r8$lambda$qUIZREW5JwXhwQQrgSEOW4bQgjo`, `finish`, `getBinding`, `getLayoutInflater`, `onCreate`, `onCreate$lambda$0`, `setBinding`, `setContentView`

### com.venter.hopweb.ImageActivity
- **extends:** `com.venter.hopweb.BaseActivity`
- **methods:** `getIntent`, `onCreate`, `setContentView`

### com.venter.hopweb.LangSetChangedActivity
- **extends:** `com.venter.hopweb.BaseActivity`
- **methods:** `$r8$lambda$3sK6Swpg-K054n1gL41ln2vGimE`, `finish`, `getBinding`, `getLayoutInflater`, `onCreate`, `onCreate$lambda$0`, `setBinding`, `setContentView`

### com.venter.hopweb.MainActivity
- **extends:** `com.venter.hopweb.BaseActivity`
- **methods:** `$r8$lambda$-5Sz-DsDsbFF4fswpQ1R34lhlS0`, `$r8$lambda$3VhKqhkHKVnUfEIshDvYZcZiJxM`, `$r8$lambda$4o0WIvxZfN7ZEqd5xZT-Hm4dlEM`, `$r8$lambda$8FLstwogV0-lJxYvKvEags3Lq5E`, `$r8$lambda$APRAK8h-ig2dQvqkpGzCbmPVxoA`, `$r8$lambda$AjKdrausOzAFeW9cYnR8M2-2NA4`, `$r8$lambda$BPauP9idIq72DjhXs8FfEFljDpY`, `$r8$lambda$C53l36bakx2XSysay8n5kEaWm0k`, `$r8$lambda$CWRX_WGp5pls6Vj-xPeJk97A9os`, `$r8$lambda$Cb9qsHGUWiYmtWVkG3hE2BUH0FQ`, `$r8$lambda$CqyM4-7PsSWwoXzwmJva3MpIjhg`, `$r8$lambda$D-zzsQk2T5Spa8g9bClUwL4esbs`, `$r8$lambda$E5mqcgEyuFYeZ1nomYRAZ1Z4ryc`, `$r8$lambda$EKTbcZhKRK-r4cVvB7adw1HW_oM`, `$r8$lambda$FMc-aMLCfMMXF9H7jHsCSf7tfTs`, `$r8$lambda$Fn9fYwF2qeIN4j0lG-G8048Jbaw`, `$r8$lambda$FvyVQGKaTfEZdT_wqu4tEHdkUzU`, `$r8$lambda$K1Rr3uiKGNsRufUn2u8YOGqzEEs`, `$r8$lambda$LAY6Uhstv6-YZAZQLQbSyH_5RZA`, `$r8$lambda$LBLHOAeDp4fV5GGOIxmBmtrvNd0`, `$r8$lambda$N4fbYjq2FFdQBiYFtZyBhXVjV-M`, `$r8$lambda$STRGN6tzyQlEPfgtuqEHjJ4jUuw`, `$r8$lambda$Sc7PNo198XAUixb42SIsATQfQnw`, `$r8$lambda$T5TTotVhZ6qS0-kfEKlRdEzfHzY`, `$r8$lambda$Uw5OA0vvg2IpbPGB-TF_hRlaZPY`, `$r8$lambda$V7RsM8FSilIKjkM_fjiH-2AGNd0`, `$r8$lambda$WGHDctuJukGo9WAuKo-7HT3Pxzs`, `$r8$lambda$WLuWK3NX3Hz5Qe08IZrttzUchXk`, `$r8$lambda$YV3Cz4eZmmEYnvIfN5DzeBqX55k`, `$r8$lambda$aP00nV4VMtao6AAvDs9UjqEIYL0`, `$r8$lambda$bp1joAtQYzSlcqt-znjhQKibC04`, `$r8$lambda$c3lwXghDlw7v3KYmVGmSlH40kyY`, `$r8$lambda$cgMZfuHEofyU9vJoJwStxH4URH0`, `$r8$lambda$d4qJm3dqeNRvdxymrkklU6uA5sg`, `$r8$lambda$ennf1lZlp8mBpdKAb2TiDXnubPE`, `$r8$lambda$fgbGnsURdKVogYXcP3GzSLXzY2Y`, `$r8$lambda$hHdqC-P3CSHeDqGGQ3Ex71_LOyc`, `$r8$lambda$i_LFYxa5CZGSHdmG4s3HI_v0PIM`, `$r8$lambda$jtxZ4Ncz6yr_U0JBuamLoVXppsQ`, `$r8$lambda$jyyi5e1xQOMI-Vrmj1tkQVI2a70`, `$r8$lambda$kqLbBpob2rkU43dZdEwVceBkxfY`, `$r8$lambda$mQjc5KU4_rgmdlJ2LGZ5k706k1g`, `$r8$lambda$mj0nS6pfZDppWRzFiGBjl01RNlc`, `$r8$lambda$mo6uLSfbV7K21IOVaeVYxRKFQ6M`, `$r8$lambda$nCvuNjRJMP8WNEoywRqN6jIOqoI`, `$r8$lambda$oiQpV1j2rSoXwZenzgV7-LvxGpg`, `$r8$lambda$qR74ZoXMa3ftZI4qdMqiAcg9Me4`, `$r8$lambda$qTT43K7LKoVuGY0E3JV39khIfrY`, `$r8$lambda$rQcGTO3xeswcACjOr5uajkUtNuU`, `$r8$lambda$rUPRBrRCt4Mec4jl3PXovwyjINU`, `$r8$lambda$rkmoqHaZpFOqNIq49p3FMLNY2Vc`, `$r8$lambda$rtD8ueZMmJ9hcPrLEhDCnYWDXPY`, `$r8$lambda$sTjFvRDm6ZBZR0JuaT01a1xmd-k`, `$r8$lambda$xG_8qh_6XUfG9u6Ytrc8ViPryMI`, `$r8$lambda$ypdDwqICrhWdtWQC6yI4Z0Qj8kM`, `$r8$lambda$yvh2tdFAFjPnumnXz1UdoeEhtoI`, `access$reloadProjects`, `addProj`, `addProj$lambda$27`, `addProj$lambda$28`, `addProj$lambda$29`, `addProj$lambda$40`, `addProj$lambda$40$lambda$39`, `addProj$lambda$40$lambda$39$lambda$31`, `addProj$lambda$40$lambda$39$lambda$31$lambda$30`, `addProj$lambda$40$lambda$39$lambda$34`, `addProj$lambda$40$lambda$39$lambda$34$lambda$33`, `addProj$lambda$40$lambda$39$lambda$34$lambda$33$lambda$32`, `addProj$lambda$40$lambda$39$lambda$36`, `addProj$lambda$40$lambda$39$lambda$36$lambda$35`, `addProj$lambda$40$lambda$39$lambda$38`, `addProj$lambda$40$lambda$39$lambda$38$lambda$37`, `addProj$lambda$54`, `addProj$lambda$54$lambda$53`, `addProj$lambda$54$lambda$53$lambda$42`, `addProj$lambda$54$lambda$53$lambda$42$lambda$41`, `addProj$lambda$54$lambda$53$lambda$44`, `addProj$lambda$54$lambda$53$lambda$44$lambda$43`, `addProj$lambda$54$lambda$53$lambda$46`, `addProj$lambda$54$lambda$53$lambda$46$lambda$45`, `addProj$lambda$54$lambda$53$lambda$48`, `addProj$lambda$54$lambda$53$lambda$48$lambda$47`, `addProj$lambda$54$lambda$53$lambda$50`, `addProj$lambda$54$lambda$53$lambda$50$lambda$49`, `addProj$lambda$54$lambda$53$lambda$52`, `addProj$lambda$54$lambda$53$lambda$52$lambda$51`, `addProj$lambda$56`, `addProj$lambda$56$lambda$55`, `getBinding`, `getFilesDir`, `getLayoutInflater`, `getResources`, `getString`, `getSupportFragmentManager`, `onCreate`, `onCreate$lambda$0`, `onCreate$lambda$10`, `onCreate$lambda$11`, `onCreate$lambda$12`, `onCreate$lambda$14`, `onCreate$lambda$14$lambda$13`, `onCreate$lambda$16`, `onCreate$lambda$16$lambda$15`, `onCreate$lambda$19`, `onCreate$lambda$9`, `onCreate$lambda$9$lambda$2`, `onCreate$lambda$9$lambda$2$lambda$1`, `onCreate$lambda$9$lambda$8`, `onCreate$lambda$9$lambda$8$lambda$7`, `onCreate$lambda$9$lambda$8$lambda$7$lambda$4`, `onCreate$lambda$9$lambda$8$lambda$7$lambda$4$lambda$3`, `onCreate$lambda$9$lambda$8$lambda$7$lambda$6`, `onCreate$lambda$9$lambda$8$lambda$7$lambda$6$lambda$5`, `onResume`, `onWindowFocusChanged`, `onWindowFocusChanged$lambda$59$lambda$57`, `onWindowFocusChanged$lambda$59$lambda$58`, `reloadProjects`, `reloadProjects$lambda$20`, `reloadProjects$lambda$26`, `reloadProjects$lambda$26$lambda$24`, `reloadProjects$lambda$26$lambda$24$lambda$23`, `reloadProjects$lambda$26$lambda$24$lambda$23$lambda$22`, `reloadProjects$lambda$26$lambda$25`, `runAndIfNotFrontRunWhenResume`, `runOnUiThread`, `setBinding`, `setContentView`, `startActivity`, `toast`

### com.venter.hopweb.MainApplication
- **extends:** `android.app.Application`
- **methods:** `onCreate`

### com.venter.hopweb.PermissionActivity
- **extends:** `com.venter.hopweb.BaseActivity`
- **methods:** `$r8$lambda$HqL1kTBixauKw6x7tNkt5R0SVR0`, `$r8$lambda$maPJQMSL4wbjstZ7aKzhVX5YuW0`, `finish`, `getLayoutInflater`, `lambda$onCreate$0`, `lambda$onCreate$1`, `onCreate`, `onKeyDown`, `setContentView`, `showPermissionDialog`, `startActivity`, `toast`

### com.venter.hopweb.PolicyActivity
- **extends:** `com.venter.hopweb.BaseActivity`
- **methods:** `$r8$lambda$9SFttt7UZGdoOj_FxomqSyUzsyI`, `$r8$lambda$G5EMuzwMl0M23rYd8s1ljskQJq4`, `$r8$lambda$OzkGj822HZpt25OSp6MxMyteOi8`, `$r8$lambda$qzM4Enz5WcY19QdasvNrXJW8S8M`, `finish`, `getBinding`, `getLayoutInflater`, `onCreate`, `onCreate$lambda$0`, `onCreate$lambda$1`, `onCreate$lambda$2`, `onCreate$lambda$3`, `setBinding`, `setContentView`, `startActivity`

### com.venter.hopweb.PreviewActivity
- **extends:** `com.venter.hopweb.BaseActivity`
- **methods:** `$r8$lambda$XQBIV99Xg54_QFuixRIVYdDX6v0`, `$r8$lambda$XuRm623IUUzCTgwBZnHNvSUdMu4`, `$r8$lambda$ZF7_7OnSc_5YxIo3s41HkCdl-fg`, `-$$Nest$fgetbinding`, `-$$Nest$fgetfirstUrl`, `-$$Nest$fgetisFirstPage`, `-$$Nest$fputfirstUrl`, `-$$Nest$fputisFirstPage`, `downloadFileFromBase64`, `finish`, `getAssets`, `getIntent`, `getJsControlScript`, `getLayoutInflater`, `getPackageManager`, `getResources`, `getString`, `lambda$downloadFileFromBase64$1`, `lambda$downloadFileFromBase64$2`, `lambda$onCreate$0`, `onCreate`, `onCreateOptionsMenu`, `onKeyDown`, `onOptionsItemSelected`, `preview`, `runOnUiThread`, `setContentView`, `setSupportActionBar`, `startActivity`, `startActivityIfNeeded`, `toast`

### com.venter.hopweb.ProjectAdapter
- **extends:** `androidx.recyclerview.widget.RecyclerView$Adapter`
- **methods:** `$r8$lambda$GUs0Ko-awfUYVos0ebtzob5nFoo`, `$r8$lambda$nhpKHXjE2aXZANone-3hoE3GGig`, `getDataBeanArray`, `getItemCount`, `getOnItemClickListener`, `getOnItemLongClickListener`, `onBindViewHolder`, `onBindViewHolder$lambda$0`, `onBindViewHolder$lambda$1`, `onCreateViewHolder`

### com.venter.hopweb.ProjectListActivity
- **extends:** `com.venter.hopweb.BaseActivity`
- **methods:** `$r8$lambda$0r6IZKNqo7S1XiRsTv1CfbFsVmc`, `$r8$lambda$3L4pey_zy8zsz7q7ZNlpc5Y8b8E`, `$r8$lambda$4klRm4kEDDuUPIuFK64hwDdCIaI`, `$r8$lambda$584d5Mv0YMVFxKbZSAXzS-TOXJ8`, `$r8$lambda$jXC21pc-i-MDJod079OaeEWQqbw`, `$r8$lambda$lho7YydOSPHCWo6s_xQc-hzWfOM`, `$r8$lambda$qeQnMSJ2q2J81cvB6c09GOYe2_Y`, `finish`, `getBinding`, `getLayoutInflater`, `getString`, `onCreate`, `onCreate$lambda$0`, `onCreate$lambda$3`, `onCreate$lambda$3$lambda$1`, `onCreate$lambda$3$lambda$2`, `reloadProjects`, `reloadProjects$default`, `reloadProjects$lambda$7`, `reloadProjects$lambda$7$lambda$6`, `reloadProjects$lambda$7$lambda$6$lambda$5`, `runOnUiThread`, `setBinding`, `setContentView`, `startActivity`

### com.venter.hopweb.R

### com.venter.hopweb.SettingActivity
- **extends:** `com.venter.hopweb.BaseActivity`
- **methods:** `$r8$lambda$-9sBy5dATfaSDcqcDMjq7oFl-FE`, `$r8$lambda$-qtq5iHF9vydGwgadQBTlJKK5_A`, `$r8$lambda$7L4Xim6ZlTJGcVTju0RPODABlwg`, `$r8$lambda$9krHJEe3kA6tKeDINArDv25Su9w`, `$r8$lambda$A7KFZxMuHpQ_ucc_H0Yx-4KTMGg`, `$r8$lambda$HKTBWuw1zSVX2QJSuV1O0U3LDYk`, `$r8$lambda$LHG2OzxpNgyTDpKK4gmhWzp-a_s`, `$r8$lambda$OPOeXgo3zZ_NSLp1An5sJPgd8Zc`, `$r8$lambda$OXeAjBsPIkLzJgpmvdCDvOW_X1s`, `$r8$lambda$Uengz_w3C0FJMqDRv-x87jjdqzo`, `$r8$lambda$WHzwBGfxXC-jl6qaXtj9nj18q04`, `$r8$lambda$XlqWMa01HI8Lm_AeVIJEJLtH8TU`, `$r8$lambda$fn4RI56bqXLTN4BaPScmtFVotQs`, `$r8$lambda$lSS4D6FNMJvVgJDzM0Z6aw1RwZI`, `$r8$lambda$lrmfM2PRThhh6WUXV34NO4IYfEw`, `$r8$lambda$nRBdkUqVfMd4UBs6T4wkymQPrjg`, `$r8$lambda$qlL1clSwfTlVYiFT68DZAffbw7w`, `$r8$lambda$roG2dq-zWDSM0OeeMYTFpbipOys`, `deleteDatabase`, `getApplicationContext`, `getFilesDir`, `getLayoutInflater`, `getString`, `lambda$onCreate$0`, `lambda$onCreate$1`, `lambda$onCreate$2`, `lambda$onCreate$3`, `lambda$setValue$10`, `lambda$setValue$11`, `lambda$setValue$12`, `lambda$setValue$13`, `lambda$setValue$14`, `lambda$setValue$15`, `lambda$setValue$16`, `lambda$setValue$17`, `lambda$setValue$18`, `lambda$setValue$19`, `lambda$setValue$20`, `lambda$setValue$21`, `lambda$setValue$4`, `lambda$setValue$5`, `lambda$setValue$6`, `lambda$setValue$7`, `lambda$setValue$8`, `lambda$setValue$9`, `onCreate`, `runOnUiThread`, `setContentView`, `setValue`, `startActivity`, `toast`

### com.venter.hopweb.UpdateManager
- **methods:** `-$$Nest$sfgeturl`, `check`, `checkForDialog`, `lambda$check$0`

### com.venter.hopweb.databinding.AbiWarningBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.AboutBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.AppConvertBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.BootBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.BottomSwitcherBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.ClubClientBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.EditorBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.ErrorBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.ExplorerItemBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.IdeaCardBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.IdeaSkyAlertBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.IdeaSkyDetailBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.IdeaSkyItemBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.IdeaSkyItemsActivityBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.IdeaSkyUploadBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.IdeaSkyUploadFinishBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.IdeaskyBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.IdeaskyOobeBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.IdeaskyUploadChooseBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.LangSetChangedBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.MainBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.PermissionBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.PolicyBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.PreviewBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.ProjectListBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.ProjectPanelBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.ProjectPanelFlexBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.databinding.SettingsBinding
- **methods:** `bind`, `getRoot`, `inflate`

### com.venter.hopweb.explorer.ExplorerAdapter
- **extends:** `androidx.recyclerview.widget.RecyclerView$Adapter`
- **methods:** `$r8$lambda$05l8qHU1IEw3YWal0iF0jAn4jI8`, `$r8$lambda$3rsclPhSoNXEBPrFn14RGYLun1k`, `$r8$lambda$RDedvzE3luz4rtTJDef2y3dmXsg`, `$r8$lambda$aB1VjWYuQME4MYusmRQVVWu4V8k`, `$r8$lambda$grveNSlWtOwESO5wN3xfxkQ0780`, `$r8$lambda$mvkH8Yp_4d9gu0RfPGNxuDs1eoI`, `getItemCount`, `onBindViewHolder`, `onBindViewHolder$lambda$0`, `onBindViewHolder$lambda$1`, `onBindViewHolder$lambda$3`, `onBindViewHolder$lambda$3$lambda$2`, `onBindViewHolder$lambda$4`, `onBindViewHolder$lambda$5`, `onCreateViewHolder`

### com.venter.hopweb.explorer.ExplorerFileModel
- **methods:** `getName`, `getPath`, `getType`

### com.venter.hopweb.explorer.ExplorerView
- **extends:** `androidx.recyclerview.widget.RecyclerView`
- **methods:** `$r8$lambda$FYN8u0Q_GyA7QNVu5PokaLsBV5o`, `$r8$lambda$ssvH-YPc5KF5v0skYG_zjFKunh0`, `access$getOnItemClickListener$p`, `getContext`, `getNameFilter`, `getNowDirectoryFile`, `go`, `go$default`, `go$lambda$2`, `go$lambda$2$lambda$1`, `initialize`, `isNightTheme`, `refresh`, `setAdapter`, `setLayoutManager`, `setNameFilter`, `setNightTheme`, `setNowDirectoryFile`

### com.venter.hopweb.explorer.FileType
- **extends:** `java.lang.Enum`
- **methods:** `$values`, `ordinal`, `valueOf`, `values`

### com.venter.hopweb.explorer.OnExplorerNavigateListener
- **methods:** `onSkip`

### com.venter.hopweb.explorer.OnItemClickListener
- **methods:** `onClick`

### com.venter.hopweb.explorer.OnItemLongClickListener
- **methods:** `onLongClick`

### com.venter.hopweb.ideasky.IdeaCard
- **extends:** `com.google.android.material.card.MaterialCardView`
- **methods:** `$r8$lambda$c9iORm5NyCQR8FxM9WTBe_UDDZ4`, `access$getBinding$p`, `addView`, `getContext`, `getRid`, `init`, `init$lambda$0`, `setCardBackgroundColor`, `setCardElevation`, `setClickable`, `setFocusable`, `setId`, `setLayoutParams`, `setOnClickListener`, `setRadius`, `setRid`, `setStrokeColor`, `setStrokeWidth`

### com.venter.hopweb.ideasky.IdeaSkyAdapter
- **extends:** `androidx.recyclerview.widget.RecyclerView$Adapter`
- **methods:** `$r8$lambda$BKFDdrKvIKA4MRJWuXKZ2QQAGiQ`, `$r8$lambda$sVDEriGdqx1RhY2g6QGHAnZYLUw`, `$r8$lambda$zFafXxLW8xEWC-ZBQhf5bptcG1c`, `getActivity`, `getHeight`, `getItemCount`, `getWidth`, `isGlobal`, `onBindViewHolder`, `onBindViewHolder$lambda$2`, `onBindViewHolder$lambda$2$lambda$1`, `onBindViewHolder$lambda$2$lambda$1$lambda$0`, `onCreateViewHolder`

### com.venter.hopweb.ideasky.IdeaSkyAlertFragment
- **extends:** `com.venter.hopweb.BaseFragment`
- **methods:** `$r8$lambda$YNGPiCaXqXDz-CELff68Ge6FeC0`, `$r8$lambda$pCRMNnvY53FPNI_jjzFmfCp7IPQ`, `$r8$lambda$xB2Z3B8Qz6wCoW5Es1tt7BCkQJ0`, `getArguments`, `getBinding`, `getParentFragmentManager`, `onCreateView`, `onViewCreated`, `onViewCreated$lambda$4`, `onViewCreated$lambda$4$lambda$3`, `onViewCreated$lambda$4$lambda$3$lambda$2`, `setBinding`

### com.venter.hopweb.ideasky.IdeaSkyFragment
- **extends:** `com.venter.hopweb.BaseFragment`
- **methods:** `$r8$lambda$-vXUg8jLdXOa4dWAzW6IuXfH-fc`, `$r8$lambda$2QhQUIruAgiai0NbkCrb311yi98`, `$r8$lambda$5L-1gixB1iPe7igV9-DV-REYEq4`, `$r8$lambda$9lw-oFdCqqpS87w4LfbWpieb_qw`, `$r8$lambda$QQaFcVyrl2M9T9XKzl3RbG4tVQ0`, `$r8$lambda$QdO3WAMQDsE59ey-rt3ekV8uYNk`, `$r8$lambda$Vz6Dyn3uEWHKgCZo1LT38v1rnRc`, `$r8$lambda$ahfQJbv-VpwCmI3o98yoJJQmTys`, `$r8$lambda$cmAuroYLMRg8phEu_XtgFYxvs5w`, `$r8$lambda$jNk2l7OnIfwW0IAbAFByCkKvr5s`, `$r8$lambda$pN9MvCJAzZbb76pr9ab_dURhFao`, `$r8$lambda$ude1IzvDw_uFh50TL-pMSEv9hGQ`, `$r8$lambda$wlsxCIc6qjor7sCHUoLDn7mYIwU`, `getActivity`, `getArguments`, `getBinding`, `getContext`, `getParentFragmentManager`, `isLoaded`, `isLoading`, `onCreateView`, `onViewCreated`, `onViewCreated$lambda$0`, `onViewCreated$lambda$1`, `onViewCreated$lambda$2`, `reLoad`, `reLoad$lambda$13`, `reLoad$lambda$13$lambda$12`, `reLoad$lambda$13$lambda$12$lambda$11`, `reLoad$lambda$13$lambda$12$lambda$11$lambda$10`, `reLoad$lambda$13$lambda$12$lambda$8`, `reLoad$lambda$13$lambda$12$lambda$8$lambda$7`, `reLoad$lambda$13$lambda$12$lambda$8$lambda$7$lambda$3`, `reLoad$lambda$13$lambda$12$lambda$8$lambda$7$lambda$6`, `reLoad$lambda$13$lambda$12$lambda$8$lambda$7$lambda$6$lambda$5`, `reLoad$lambda$13$lambda$12$lambda$8$lambda$7$lambda$6$lambda$5$lambda$4`, `requireActivity`, `requireArguments`, `requireContext`, `setBinding`, `setLoaded`, `setLoading`, `startActivity`

### com.venter.hopweb.ideasky.IdeaSkyOOBEFragment
- **extends:** `com.venter.hopweb.BaseFragment`
- **methods:** `$r8$lambda$7-ZfqoFo5IFvSzSpbRNW-5qBPZc`, `$r8$lambda$B1-_Lj2j0Rh60XoA3DgZKv5U2IY`, `getBinding`, `getContext`, `getParentFragmentManager`, `onCreateView`, `onViewCreated`, `onViewCreated$lambda$2`, `onViewCreated$lambda$2$lambda$1`, `setBinding`

### com.venter.hopweb.ideasky.ServerHelper

### com.venter.hopweb.ideasky.ShortInfModel
- **methods:** `getAuthor`, `getDescription`, `getLongDescription`, `getRid`, `getScreenshotsNumber`, `getTime`, `getTitle`, `getWebsiteUrl`

### com.venter.hopweb.u.Base64
- **methods:** `decode`, `encode`, `isData`, `isPad`, `isWhiteSpace`, `removeWhiteSpace`

### com.venter.hopweb.u.DonateUtils
- **methods:** `$r8$lambda$2nM10yUABCUZE_ZvDfXMCfCMfvc`, `donateWeixin`, `getActivity`, `showDialog`, `showDialog$lambda$0`

### com.venter.hopweb.u.MailStation

### com.venter.hopweb.u.ProjectHelper

### com.venter.hopweb.u.Settings
- **methods:** `$r8$lambda$Xh-QVghrcjjTa3wqmnv3CtChbYc`, `$r8$lambda$Y_p1hi_RE9om2-f96AeH32YEQ2c`, `getControlJsPath`, `lambda$saveSettings$0`, `lambda$saveSettings$1`, `lambda$saveSettings$2`, `saveSettings`

### com.venter.hopweb.u.SoftKeyBoardListener
- **methods:** `$r8$lambda$3BkUFC3B3nTFG-PVLp64u2hMlGg`, `lambda$new$0`, `setListener`, `setOnSoftKeyBoardChangeListener`

### com.venter.hopweb.u.StyleTable
- **methods:** `getAll`, `sortAll`

### com.venter.hopweb.u.StyleUtils
- **methods:** `MIUISetStatusBarLightMode`, `getSystemProperty`, `intent`, `isEMUI`, `isFlyme`, `isMIUI`, `isPropertiesExist`, `setAndroidNativeLightStatusBar`, `setFlymeLightStatusBar`

### com.venter.hopweb.u.TipsManager
- **methods:** `create`, `has`, `isNewVersion`, `updateLocalVersion`

### com.venter.hopweb.u.Utils
- **methods:** `appendHeader`, `copyDataToSD`, `copyDir`, `copyFile`, `copyText`, `delete`, `deleteDirectory`, `deleteFile`, `downloadBySystem`, `downloadNet`, `dp2px`, `encodeUrl`, `exportProjToZip`, `finishWaiting`, `getBitmapDrawableFromVectorDrawable`, `getBitmapFromVectorDrawable`, `getBooleanString`, `getClipText`, `getClipboardContent`, `getColor`, `getContentFilePath`, `getElementLevel`, `getErrorMsg`, `getFileLastTime`, `getFileRealNameFromUri`, `getHtmlText`, `getInputStreamFromUri`, `getIpAddressString`, `getMultipleText`, `getRealFileName`, `getRelativePath`, `getRippleDrawable`, `getSpecialRippleDrawable`, `getTimeText`, `getTransitionDrawable`, `getVersionCode`, `getVersionName`, `hideIME`, `installApkFile`, `isBinaryFile`, `isBitmapPicture`, `isConnected`, `isHaveAuthorities`, `isProcessExist`, `isResponsive`, `isScreenPotrait`, `isServiceExisted`, `isWebPicture`, `joinQQGroup`, `lambda$exportProjToZip$7`, `lambda$showQQGroup$1`, `lambda$showQQGroup$2`, `lambda$showQQGroup$3`, `lambda$showTGGroup$4`, `lambda$showTGGroup$5`, `lambda$showTGGroup$6`, `lambda$showWaitAndRunInThread$0`, `makeSelectable`, `mergeArrays`, `openFile`, `openUrl`, `px2dp`, `px2sp`, `read`, `readStream`, `restartApplication`, `runCommand`, `runCommandAndGetProcess`, `saveBitmapAsPng`, `setAlphaAnimation`, `setMargin`, `setMargins`, `setPaddings`, `shareFile`, `shareText`, `showError`, `showQQGroup`, `showTGGroup`, `showWaitAndRunInThread`, `sp2px`, `startWaiting`, `toast`, `upZipFileDir`, `write`

### com.venter.hopweb.u.Vers
- **methods:** `getClubIDFile`, `getHWFavicon`, `getProjectsFolder`, `getVenterFolder`, `updateInfUrl`, `updateUrl`

### com.venter.hopweb.u.ZipUtil
- **methods:** `compress`, `toZip`

### com.venter.hopweb.u.add.AddCSS

### com.venter.hopweb.u.add.AddClass
- **methods:** `-$$Nest$fgetEo`, `AddEms`, `builder`, `getContext`

### com.venter.hopweb.u.add.AddScript

### com.venter.hopweb.u.add.AddStyle
- **methods:** `-$$Nest$mInStyle`, `InStyle`, `add`

### com.venter.hopweb.u.add.AddTable
- **methods:** `OutputTable`

### com.venter.hopweb.u.add.ChooseColor
- **methods:** `-$$Nest$fgetcolorString`, `-$$Nest$fputcolorString`, `choose`, `convertToRGB`, `noWell`

### com.venter.hopweb.u.server.database.DatabaseProcess
- **extends:** `android.app.Service`
- **methods:** `$r8$lambda$efm-t1JxLz92umsDM3vGxoScJoM`, `getApplicationInfo`, `getFilesDir`, `isStarted`, `onBind`, `onStartCommand`, `onStartCommand$lambda$0`, `setStarted`, `stopSelf`

### com.venter.hopweb.u.server.database.DatabaseServerHelper
- **methods:** `$r8$lambda$OdbPkG-Mf7gaczYZ8HCNlmXuvYA`, `$r8$lambda$VU9qvzvVNwdN4hcAZR8GWZrhaPM`, `$r8$lambda$d-iL6imJeuMPPclD-mLUv1X03HM`, `$r8$lambda$jc_nOq5wjWo5roiAfjF7-MMoFFk`, `access$getServiceIntent`, `checkDatabase`, `createAndGetCnfPath`, `createAndGetCnfPath$default`, `errorRunnable$lambda$0`, `getContext`, `getErrFlagFile`, `getErrorRunnable`, `getErrorTryingTimes`, `getPidFile`, `getProcessPID`, `getProjectDir`, `getRunRunnable`, `getRunning`, `getServiceIntent`, `initDatabase`, `runRunnable$lambda$1`, `setErrorRunnable`, `setErrorTryingTimes`, `setProcessPID`, `setRunRunnable`, `setRunning`, `startServerSafely`, `startServerSafely$lambda$3`, `startServerSafely$lambda$3$lambda$2`, `stopServer`

### com.venter.hopweb.u.server.php.PHPProcess
- **extends:** `android.app.Service`
- **methods:** `$r8$lambda$1FhIZu176qw9F17LxANhJ4E1Pcs`, `getApplicationInfo`, `getFilesDir`, `isStarted`, `onBind`, `onStartCommand`, `onStartCommand$lambda$0`, `setStarted`, `stopSelf`

### com.venter.hopweb.u.server.php.PHPServerHelper
- **methods:** `$r8$lambda$7LIbzaBA_ggchgXp2mjErIvhO0k`, `access$getServiceIntent`, `getContext`, `getErrorFile`, `getErrorTryingTimes`, `getPidFile`, `getProcessPID`, `getProjectDir`, `getRunning`, `getServiceIntent`, `setErrorTryingTimes`, `setProcessPID`, `setRunning`, `startServer`, `startServer$lambda$0`, `stopServer`

### com.venter.hopweb.w.BottomSwitcher
- **extends:** `android.widget.LinearLayout`
- **methods:** `active`, `inactive`, `setClickable`, `setFocusable`, `setIsClickable`, `setOnClickListener`

### com.venter.hopweb.w.CharsAdder
- **extends:** `android.widget.LinearLayout`
- **methods:** `$r8$lambda$5MFkzz_Vo0IQWx3VtkrXkQzPL20`, `$r8$lambda$YSibN7dzKw9G18Ar0HaY7EurOVI`, `$r8$lambda$ZIR1MQjY2uMIa2M5xKwqR73Tpyg`, `$r8$lambda$aIwX0OBSeWLtr8XSI40fe2VLHT4`, `$r8$lambda$uD0D8j8sOtiylzSrVesDZr903NY`, `addView`, `getCharButton`, `getContext`, `init`, `lambda$init$0`, `lambda$init$1`, `lambda$init$2`, `lambda$init$3`, `lambda$init$4`, `lambda$init$5`, `lambda$init$6`, `setBackgroundColor`, `setLayoutParams`, `setOrientation`

### com.venter.hopweb.w.Dl
- **methods:** `create`, `show`, `showNormal`

### com.venter.hopweb.w.Editor
- **extends:** `com.venter.codeeditor.CodeEditor`
- **methods:** `$r8$lambda$ByPRtAPM-xAgZ1WX8MJu_HIUIR0`, `$r8$lambda$JX42D1T74ApbFI4KoJbMrJSLff8`, `_init_$lambda$0`, `destroyDrawingCache`, `format`, `getCaretPosition`, `getCaretRow`, `getContext`, `getSelectionEnd`, `getString`, `gotoLine`, `insert`, `jumpToLine`, `jumpToLine$lambda$2`, `moveCaretLeft`, `moveCursor`, `redo`, `replaceAll`, `setLayoutParams`, `setOnSelectionChangedListener`, `setSelection`, `setText`, `undo`

### com.venter.hopweb.w.EditorArea
- **extends:** `android.widget.LinearLayout`
- **methods:** `fitSystemWindows`, `onApplyWindowInsets`

### com.venter.hopweb.w.HButton
- **extends:** `android.widget.LinearLayout`
- **methods:** `addView`, `getContext`, `getLayoutParams`, `requestLayout`, `setBackground`, `setClickable`, `setFocusable`, `setLayoutParams`, `setOnClickListener`, `setOrientation`, `setPadding`

### com.venter.hopweb.w.HWToolBar
- **extends:** `androidx.appcompat.widget.Toolbar`
- **methods:** `addView`, `controlProgressBar`, `getContext`, `init`, `setLogo`, `setSubtitle`, `setTitle`

### com.venter.hopweb.w.ProgressDialog
- **methods:** `Show`, `dismiss`, `isShowing`, `lambda$new$0`

### com.venter.hopweb.w.TemplateButton
- **extends:** `android.widget.LinearLayout`
- **methods:** `addView`, `check`, `getContext`, `init`, `removeAllViews`, `setBackground`, `setLayoutParams`, `setOnClickListener`, `setVisibility`

### com.venter.hopweb.w.base.AutoLinefeedLayout
- **extends:** `android.view.ViewGroup`
- **methods:** `getChildAt`, `getChildCount`, `getDesiredHeight`, `getMeasuredWidth`, `getPaddingBottom`, `getPaddingLeft`, `getPaddingRight`, `getPaddingTop`, `layoutHorizontal`, `measureChild`, `onLayout`, `onMeasure`, `setChildFrame`, `setLayoutParams`

### com.venter.hopweb.w.base.ChoiceLayout
- **extends:** `android.widget.LinearLayout`
- **methods:** `addView`, `build`, `getContext`, `getText`, `setId`, `setLayoutParams`, `setOrientation`, `setPadding`

### com.venter.hopweb.w.base.CircleButton
- **extends:** `android.widget.RelativeLayout`
- **methods:** `addView`, `barMode`, `circleMode`, `getContext`, `removeAllViews`, `setBackground`, `setBackgroundDrawable`, `setGravity`, `setLayoutParams`, `setPadding`

### com.venter.hopweb.w.base.ColorLayout
- **extends:** `android.widget.LinearLayout`
- **methods:** `addView`, `build`, `getContext`, `getText`, `setId`, `setLayoutParams`, `setOrientation`, `setPadding`

### com.venter.hopweb.w.base.ComplementTextLayout
- **extends:** `android.widget.LinearLayout`
- **methods:** `addView`, `getContext`, `getEditText`, `getText`, `getTextWithTip`, `getTip`, `setEditText`, `setLayoutParams`, `setOrientation`, `setPadding`

### com.venter.hopweb.w.base.FeedButton
- **extends:** `android.widget.LinearLayout`
- **methods:** `addView`, `getContext`, `minimise`, `setBackground`, `setClickable`, `setForegroundColor`, `setGravity`, `setLayoutParams`, `setOnClickListener`, `setOnLongClickListener`, `setOrientation`, `setPadding`, `setVisibility`

### com.venter.hopweb.w.base.FeedCup
- **extends:** `android.widget.LinearLayout`
- **methods:** `addView`, `getContext`, `setBackground`, `setClickable`, `setGravity`, `setLayoutParams`, `setOnClickListener`, `setOrientation`, `setPadding`

### com.venter.hopweb.w.base.FeedEditText
- **extends:** `com.venter.hopweb.w.base.FeedCup`
- **methods:** `getEditText`, `setEditText`

### com.venter.hopweb.w.base.FeedSwitcher
- **extends:** `com.venter.hopweb.w.base.FeedCup`
- **methods:** `addView`, `getContext`, `getSwitchCompat`, `makeNoPaddings`, `setBackground`, `setPadding`, `setSwitchCompat`

### com.venter.hopweb.w.base.NumLayout
- **extends:** `android.widget.LinearLayout`
- **methods:** `addView`, `build`, `getContext`, `getText`, `setId`, `setLayoutParams`, `setOrientation`, `setPadding`

### com.venter.hopweb.w.base.ObjectLayout
- **extends:** `android.widget.LinearLayout`
- **methods:** `addView`, `build`, `getContext`, `getCup`, `setId`, `setLayoutParams`, `setOrientation`, `setPadding`

### com.venter.hopweb.w.base.SelectionLayout
- **extends:** `android.widget.LinearLayout`
- **methods:** `$r8$lambda$WOIxuiqX5SApT5XMNDEJnCtROuM`, `addView`, `getContext`, `getSelectionIndex`, `init`, `init$lambda$1`, `setLayoutParams`, `setSelection`

### com.venter.hopweb.w.base.StyleLayout
- **extends:** `android.widget.LinearLayout`
- **methods:** `addView`, `build`, `getContext`, `getResources`, `getText`, `setId`, `setLayoutParams`, `setOrientation`, `setPadding`

### com.venter.hopweb.w.base.TextLayout
- **extends:** `android.widget.LinearLayout`
- **methods:** `addView`, `build`, `getContext`, `getText`, `setId`, `setLayoutParams`, `setOrientation`, `setPadding`

### com.venter.venterweaver.AppInfModel
- **methods:** `getAppIconFile`, `getAppName`, `getPackageName`, `getVersionCode`, `getVersionName`, `setAppIconFile`, `setAppName`, `setPackageName`, `setVersionCode`, `setVersionName`

### com.venter.venterweaver.BuildConfig

### com.venter.venterweaver.ErrorListener
- **methods:** `run`

### com.venter.venterweaver.FinishListener
- **methods:** `run`

### com.venter.venterweaver.R

### com.venter.venterweaver.Weaver
- **methods:** `buildAPK`, `bytesToHexString`, `copyDataToSD`, `copyFile`, `copyFile$copyDir`, `copyFile$copySdcardFile`, `delete`, `delete$deleteDirectory`, `delete$deleteFile`, `getFileMD5`, `read`, `runCommand`, `saveBitmapAsPng`, `signApk`, `unZipFileDir`, `unZipFileDir$getRealFileName`, `write`

### com.venter.venterweaver.ZipUtil
- **methods:** `calculateCrc`, `compress`, `toZip`
