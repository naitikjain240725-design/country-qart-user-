# HopWeb APK — Extracted Source Package

**App:** HopWeb (com.venter.hopweb)  
**Version:** 2.7.5 (code 112)  
**Target SDK:** 35 (Android 15)  
**Min SDK:** 24 (Android 7.0)  
**Modified by:** AiTricker (Mod APK)  

---

## Folder Structure

```
HopWeb_Source/
├── README.md                          ← यह फ़ाइल
├── manifest/
│   ├── AndroidManifest.xml            ← मुख्य Manifest (decoded)
│   ├── AndroidManifest_template.xml   ← App Convert टेम्पलेट Manifest
│   └── AndroidManifest_php_template.xml ← PHP App टेम्पलेट Manifest
├── assets/                            ← सभी Web/JS/CSS assets
│   ├── editor.html                    ← Code Editor UI (WebView)
│   ├── app-config.json                ← App configuration
│   ├── create_css.css                 ← नया CSS फ़ाइल टेम्पलेट
│   ├── create_html.html               ← नया HTML फ़ाइल टेम्पलेट
│   ├── create_html_proj.html          ← HTML Project टेम्पलेट
│   ├── create_js.js                   ← नया JS फ़ाइल टेम्पलेट
│   ├── create_json.json               ← नया JSON टेम्पलेट
│   ├── create_php.php                 ← नया PHP टेम्पलेट
│   ├── create_php_web.php             ← PHP Web टेम्पलेट
│   ├── create_xml.xml                 ← नया XML टेम्पलेट
│   ├── eruda.min.js                   ← Mobile DevTools (Eruda)
│   ├── vconsole.min.js                ← Mobile Console (vConsole)
│   ├── update_log.txt                 ← अपडेट लॉग (हिंदी/अंग्रेज़ी)
│   ├── update_log_gl.txt              ← अपडेट लॉग (Global)
│   ├── beautiful/                     ← Code Beautifier JS libs
│   │   ├── beautify.min.js
│   │   ├── beautify-css.min.js
│   │   └── beautify-html.min.js
│   └── templates/                     ← Project templates
│       ├── basic.zip                  ← Basic HTML project template
│       └── php.zip                    ← PHP project template
├── resources/
│   ├── res/                           ← Android compiled resources
│   └── template_values/
│       ├── strings.xml                ← App name string templates
│       └── themes.xml                 ← App theme templates
├── kotlin_metadata/                   ← Kotlin runtime metadata
├── META-INF/                          ← APK signature & manifest
└── class_structure/
    ├── class_report.md                ← सभी app classes की पूरी list
    ├── hopweb_core_classes.md         ← सिर्फ com.venter.* classes + methods
    └── strings_of_interest.txt        ← DEX से निकाले गए strings/URLs/keys
```

---

## मुख्य Activities (com.venter.hopweb)

| Activity | काम |
|---|---|
| `BootActivity` | Splash / Launch screen |
| `MainActivity` | मुख्य फ़ाइल मैनेजर |
| `EditorActivity` | Code Editor |
| `AppConvertActivity` | Web → APK Converter |
| `ClubClientActivity` | Club/Community |
| `AboutActivity` | About screen |
| `PolicyActivity` | Privacy Policy |
| `ABIWarningActivity` | ABI warning |

## Note
> DEX files (classes.dex, classes2.dex, classes3.dex) compiled bytecode हैं।
> पूरा Java/Kotlin source code recover करने के लिए JADX tool की
> ज़रूरत होती है जो इस environment में उपलब्ध नहीं थी।
> Web assets (HTML/JS/CSS/PHP) पूरी तरह readable हैं।
